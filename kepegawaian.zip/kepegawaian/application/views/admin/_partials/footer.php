<footer class="py-4 bg-dark mt-auto">
    <div class="container-fluid">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; <?php echo SITE_NAME ." ". Date ('Y') ?> 
            <br>Ikra Esa A'raaf Mahardika
            <br>10119271
            <br>IF7</div>           
            <div>
                <a href="#">Privacy Policy</a>
                &middot;
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
            