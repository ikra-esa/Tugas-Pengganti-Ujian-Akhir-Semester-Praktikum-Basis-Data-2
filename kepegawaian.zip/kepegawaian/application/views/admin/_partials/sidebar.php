<div class="sb-sidenav-menu">
    <div class="nav">                          
        <a class="nav-link" href="<?php echo site_url ('dashboard') ?>">
            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Dashboard
        </a>             
        <a class="nav-link" href="<?php echo site_url ('pegawai') ?>">
            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                Data Pegawai
        </a>
        <a class="nav-link" href="<?php echo site_url ('riwayat_pendidikan') ?>">
            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                Data Riwayat Pegawai
        </a>
    </div>
</div>           